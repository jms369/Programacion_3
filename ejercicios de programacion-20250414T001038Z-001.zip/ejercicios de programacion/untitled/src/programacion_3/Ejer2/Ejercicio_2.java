package programacion_3.Ejer2;

import java.util.Scanner;

public class Ejercicio_2 {

    String original[];
    String invertido[];

    Scanner sc;

    public Ejercicio_2(){
        original = new String [5];
        invertido = new String [5];

        sc = new Scanner(System.in);

    }

    public void ejecutar(){
        for(int i=0; i<original.length;i++){
            System.out.println("original[ "+i+" ]: ");
            String cadena = sc.nextLine();

            original [i] = cadena;
        }

        int ioriginal=0;
        int iinverso=4;

        while(ioriginal<original.length){

            invertido[iinverso] = original[ioriginal];

            ioriginal++;
            iinverso--;
        }

        for(int i= 0;i<invertido.length;i++){
            System.out.println("inverso [ "+i+" ]: "+ invertido[i]);
        }

    }
}
