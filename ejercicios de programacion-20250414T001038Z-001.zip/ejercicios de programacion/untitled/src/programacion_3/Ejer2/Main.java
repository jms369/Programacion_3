package programacion_3.Ejer2;

public class Main {
    public static void main(String[] args) {

        Ejercicio_2 ejer2 = new Ejercicio_2();
        ejer2.ejecutar();
    }
}
