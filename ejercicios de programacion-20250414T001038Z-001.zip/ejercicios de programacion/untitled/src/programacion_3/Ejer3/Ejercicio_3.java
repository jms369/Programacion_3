package programacion_3.Ejer3;

import java.util.Scanner;

public class Ejercicio_3 {

    int notas [];
    Scanner sc;

    public Ejercicio_3 (){
        notas = new int [5];
        sc = new Scanner(System.in);
    }

    public void ejecutar(){

        for(int i=0; i<notas.length;i++){
            System.out.println("nota [ "+i+" ]: ");
           int nota = sc.nextInt();

           notas[i]= nota;
        }

        int minimo = 10;
        int maximo= 0;

        double promedio;
        int sumaNotas =0;

        for(int i= 0; i<notas.length;i++){

            if(notas[i]<minimo){
                minimo = notas[i];
            }

            if(notas[i]>maximo){
                maximo = notas[i];
            }

            sumaNotas = sumaNotas+notas[i];

        }
        promedio = (double)sumaNotas/notas.length;

        System.out.println("Nota promedio: "+promedio);
        System.out.println("Nota maxima: "+maximo);
        System.out.println("Nota minima: "+minimo);
    }
}
