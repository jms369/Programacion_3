package programacion_3.Ejer3;

public class Main {

    public static void main(String[] args) {

        Ejercicio_3 ejer3 = new Ejercicio_3();
        ejer3.ejecutar();
    }
}
