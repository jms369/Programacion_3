package programacion_3.Ejer1;

public class Ejercicio_1 {

    int vectorNumeros [] = new int [10];

    public Ejercicio_1(){

    }
    public void ejecutar(){
        for(int i= 0; i<vectorNumeros.length;i++){

            int aleatorio= (int)(Math.random()*10+1);
            vectorNumeros[i] = aleatorio;
        }

        for(int i=0;i<vectorNumeros.length;i++){

            int numero= vectorNumeros[i];
            int cuadrado = (int) Math.pow(numero,2);
            int cubo = (int) Math.pow(numero,3);

            System.out.println("Vector números [ "+i+" ]: "+numero+" , "+cuadrado+" , "+cubo);
        }
    }
}
