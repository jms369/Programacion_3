package programacion_3.Ejer1;

public class Main {
    public static void main(String[] args) {

        Ejercicio_1 ejer1 = new Ejercicio_1();
        ejer1.ejecutar();
    }
}
