package Ejer_8;

public class Main {
    public static void main(String[] args) {
        Minas obj1 = new Minas();
        obj1.ejecutar();
    }
}
