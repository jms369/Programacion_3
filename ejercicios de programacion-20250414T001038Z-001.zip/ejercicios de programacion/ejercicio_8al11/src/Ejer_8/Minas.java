package Ejer_8;

import java.util.Scanner;

public class Minas {

    int v[][];
    String vPresentacion [][];
    Scanner sc;


    Minas(){
        v = new int[8][8];
        sc = new Scanner(System.in);

        vPresentacion = new String [8][8];

    }


    public void ejecutar() {

        //esta parte se encarga de contar la cantidad de minas, rellenar el tablero y preparar el otro tablero que se mostrara al usuario//
        int contadorTotal=0,totalMinas=0;


        for (int i = 0; i < v.length; i++) {
            for (int j = 0; j < v[i].length; j++) {

                int aleatorio = (int) (Math.random() * 8 + 1);

                v[i][j]= aleatorio;

                if(v[i][j]==8){
                    totalMinas=totalMinas+1;
                } else if (v[i][j]!=8) {
                    contadorTotal=contadorTotal+1;
                }

                String rellenoPresentacion = "*";
                vPresentacion[i][j]= rellenoPresentacion;
            }
        }

        int contadorJugador=0, eexplosionMinas=0, explosionMinas=0;

        //eexplosionMinas=explosionMinas;

        while(explosionMinas==0 && contadorJugador<=contadorTotal ){



            System.out.println("INGRESE UN NÚMERO PARA LA FILA: ");
            int fila = sc.nextInt();
            System.out.println("INGRESE UN NÚMERO PARA LA COLUMNA: ");
            int columna= sc.nextInt();

            int posFila0,posFila1,posFila2,posFila3,posFila4,posFila5,posFila6,posFila7;
            int posColum0,posColum1,posColum2,posColum3,posColum4,posColum5,posColum6,posColum7;
            int posiblesMinas =0;



           if(v[fila][columna]==8){

              explosionMinas= explosionMinas+1;

           }else{
               //primera posicion de verificacion 0//
               posFila0= fila-1;
               posColum0= columna-1;
               if(posFila0<0 || posColum0<0 || posFila0>7 || posColum0>7){

               }else if(posFila0>=0 && posFila0<=7 || posColum0>=0 && posColum0<=7){

                   if(v[posFila0][posColum0]==8){
                       posiblesMinas= posiblesMinas+1;
                   }
                   else{

                   }
               }

               //segunda posicion de verificacion 1//
               posFila1= fila-1;
               posColum1= columna;
               if(posFila1<0 || posColum1<0 || posFila1>7 || posColum1>7){

               }else if(posFila1>=0 && posFila1<=7 || posColum1>=0 && posColum1<=7){

                   if(v[posFila1][posColum1]==8){
                       posiblesMinas = posiblesMinas+1;
                   }
                   else{

                   }
               }

               //tercera posicion de verificacion 2//
               posFila2= fila-1;
               posColum2= columna+1;
               if(posFila2<0 || posColum2<0 || posFila2>7 || posColum2>7){

               }else if(posFila2>=0 && posFila2<=7 || posColum2>=0 && posColum2<=7){

                   if(v[posFila2][posColum2]==8){
                       posiblesMinas = posiblesMinas+1;
                   }
                   else{

                   }
               }

               //cuarta posicion de verificacion 3//
               posFila3= fila;
               posColum3= columna-1;
               if(posFila3<0 || posColum3<0 || posFila3>7 || posColum3>7){

               }else if(posFila3>=0 && posFila3<=7 || posColum3>=0 && posColum3<=7){

                   if(v[posFila3][posColum3]==8){
                       posiblesMinas = posiblesMinas+1;
                   }
                   else{

                   }
               }

               //quinta posicion de verificacion 4//
               posFila4= fila;
               posColum4= columna+1;
               if(posFila4<0 || posColum4<0 || posFila4>7 || posColum4>7){

               }else if(posFila4>=0 && posFila4<=7 || posColum4>=0 && posColum4<=7){

                   if(v[posFila4][posColum4]==8){
                       posiblesMinas = posiblesMinas+1;
                   }
                   else{

                   }
               }

               //sexta posicion de verificacion 5//
               posFila5= fila+1;
               posColum5= columna-1;
               if(posFila5<0 || posColum5<0 || posFila5>7 || posColum5>7){

               }else if(posFila5>=0 && posFila5<=7 || posColum5>=0 && posColum5<=7){

                   if(v[posFila5][posColum5]==8){
                       posiblesMinas = posiblesMinas+1;
                   }
                   else{

                   }
               }

               //septima posicion de verificacion 6//
               posFila6= fila+1;
               posColum6= columna;
               if(posFila6<0 || posColum6<0 || posFila6>7 || posColum6>7){

               }else if(posFila6>=0 && posFila6<=7 || posColum6>=0 && posColum6<=7){

                   if(v[posFila6][posColum6]==8){
                       posiblesMinas = posiblesMinas+1;
                   }
                   else{

                   }
               }

               //octava posicion de verificacion 7//
               posFila7= fila+1;
               posColum7= columna+1;
               if(posFila7<0 || posColum7<0 || posFila7>7 || posColum7>7){

               }else if(posFila7>=0 && posFila7<=7 || posColum7>=0 && posColum7<=7){

                   if(v[posFila7][posColum7]==8){
                       posiblesMinas = posiblesMinas+1;
                   }
                   else{

                   }
               }

               if(posiblesMinas!=0){
                   vPresentacion[fila][columna]=posiblesMinas+"";
               }
               else if(posiblesMinas==0){
                   vPresentacion[fila][columna]="null";
               }
           }

            System.out.println(" ");

            System.out.println("-----------------------------------");
            for (int i = 0; i < vPresentacion.length; i++) {

                for (int j = 0; j < vPresentacion[i].length; j++) {


                    System.out.print(vPresentacion[i][j] + " ");

                }
                System.out.println();

            }

            System.out.println("-----------------------------------");
           /* for (int i = 0; i < v.length; i++) {
                for (int j = 0; j < v[i].length; j++) {
                    System.out.print(v[i][j] + " ");

                }
                System.out.println();
            }
            System.out.println("-----------------------------------");
                System.out.println();*/

            //System.out.println("posicion :"+vPresentacion[fila][columna]);

            contadorJugador++;
            //eexplosionMinas= explosionMinas;

            /*System.out.println("explocion minas: "+explosionMinas);
            System.out.println("contador de jugador: "+contadorJugador);*/

        }


        /*for (int i = 0; i < v.length; i++) {
            for (int j = 0; j < v[i].length; j++) {
                System.out.print(v[i][j] + " ");

            }
            System.out.println();

        }*/


        //temporal
       /* System.out.println("total minas "+totalMinas);
        System.out.println("espacios en blanco "+contadorTotal);*/


    }
}

