package Ejer_6;

public class Main {

    public static void main(String[] args) {


        Ejercicio_6 obj1 = new Ejercicio_6();
        obj1.Ejecutar();
    }
}
