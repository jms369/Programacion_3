package Ejer_6;

public class Mes {

    private int  numero,cantidadDias;
    private String nombre;

    public Mes(int numero,String nombre,int cantidadDias){
        this.setNumero(numero);
        this.setNombre(nombre);
        this.setCantidadDias(cantidadDias);

    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getCantidadDias() {
        return cantidadDias;
    }

    public void setCantidadDias(int cantidadDias) {
        this.cantidadDias = cantidadDias;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
