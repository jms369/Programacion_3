package Ejer_5;

public class Main {
    public static void main(String[] args) {
        Ordenando obj1 = new Ordenando();
        obj1.ejecutar();
    }
}
