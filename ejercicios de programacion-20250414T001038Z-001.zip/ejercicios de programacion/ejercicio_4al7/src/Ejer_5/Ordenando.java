package Ejer_5;

public class Ordenando {
    int vec[];

    public Ordenando(){
        vec= new int [10];

    }

    public void ejecutar(){
        for(int i=0; i<vec.length;i++){
            int aleatorio = (int)(Math.random()*100+1);
            vec[i]= aleatorio;
        }


        for(int i=0;i<vec.length-1;i++){

            for(int j=0;j<vec.length-1;j++){


                if(vec[j]>=vec[j+1]){

                    int valorTemporal= vec[j];
                    vec[j]=vec[j+1];
                    vec[j+1]=valorTemporal;

                }

            }
            
        }

        for (int i=0;i<vec.length;i++){
            System.out.println("posicion "+i+" .- "+vec[i]);
        }

    }

}
