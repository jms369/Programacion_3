package Ejer_7;

import java.util.Scanner;

public class Sumando {

    int v1[];
    int v2[];
    int v3[];

    Scanner sc;


    public Sumando(){
        sc = new Scanner(System.in);

        v1 = new int [5];
        v2 = new int [5];
        v3 = new int [5];
    }

    public void Ejecutar(){

        for(int i=0; i<v1.length;i++){

            System.out.println("INGRESE UN NUMERO PARA el Vector1 EN LA POSICION ["+i+"]:");
            int numero1 = sc.nextInt();

            System.out.println("INGRESE UN NUMERO PARA el Vector2 EN LA POSICION ["+i+"]:");
            int numero2 = sc.nextInt();

            v1[i]= numero1;
            v2[i]= numero2;

            v3[i]= v1[i]+v2[i];
        }

        for(int i=0;i<v3.length;i++){
            System.out.println("La suma de "+v1[i]+" + "+v2[i]+" es: "+v3[i]);
        }


    }

}
