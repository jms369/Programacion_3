package Ejer_7;

public class Main {
    public static void main(String[] args) {

        Sumando obj1 = new Sumando();
        obj1.Ejecutar();
    }
}
